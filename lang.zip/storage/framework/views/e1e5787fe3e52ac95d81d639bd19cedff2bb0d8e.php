
  
<?php $__env->startSection('content'); ?>

<style>
  body{
      background-image: url(images/login-bg.jpg);
      background-size: cover;
      overflow-x: hidden;
      
  }
 
  .social-tab{
    text-align: center;
     
      border-radius: 30px;
      background-color: light; width:400px; color:rgb(0, 0, 0); height:40px;
      outline-color: black;
      margin-bottom: 20px;
      margin-top: 20px
      border: black;
      padding-top: 5px;
  }
 
  .social-tab a{
    text-decoration: none
  }
  .social-main{
    align-items: center;
    padding: 35px;
  }
  #main-login:hover{
   box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.51);
    text-decoration: bol
  }
</style>

  <div class="container-fluid" style="color: rgb(255, 255, 255); font-size: x-large;">
  <div style=" margin-left:50px; margin-top:20%">
  <div>
      <img src="Logo/Mrs web icon png.png" style="width: 60px;" alt="">
      Mrs Culture
      </div>
      <div>
          Sign in or create an account
      </div>
  </div>
  </div>
  <div style="width: 500px; margin-left: 60%; margin-top: -20%; padding:10px; background-color:white; border-radius: 10px;">
    
      <h3> <strong>Sign in</strong> <hr style="color: rgb(255, 1, 1)"></h3>
      
    
    <div class="form-body">
      <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group" style="margin-bottom: 20px;">
          <label for="email" class="col-md-4 col-form-label text-md-start">Email Address</label>
           <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
      

        </div>
        
        <div class="form-group" style="margin-bottom: 20px;">
          <label for="password" class="col-md-4 col-form-label text-md-start">Password</label>
          <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

            <label class="form-check-label" for="remember">
                Remember Me
            </label>
          </div>
        </div>
      

      <div class="mb-3 login-signup social-main">
        <div style="margin-bottom: 15px">__________Or__________</div>
          <a style="text-decoration: none;" href="https://www.facebook.com/login.php" target="_blank" rel="noopener noreferrer">
            
            <div class="social-tab" style="border: 2px rgba(0, 0, 0, 0.500) solid;" >
              
                <img class="ss" id="logo" src="Logo/facebook (1).png" alt="">
              Connect with Facebook
            </div>

          </a>


          <a style="text-decoration: none;" href="https://accounts.google.com/v3/signin/identifier?dsh=S1979752111%3A1687789335513299&continue=https%3A%2F%2Fads.google.com%2Fnav%2Flogin%3Fsubid%3Din-en-adon-awa-sch-c-bbb%21o3%7E13ada7984da217669613c301d2aefd26%7Ep71078840948%7E&followup=https%3A%2F%2Fads.google.com%2Fnav%2Flogin%3Fsubid%3Din-en-adon-awa-sch-c-bbb%21o3%7E13ada7984da217669613c301d2aefd26%7Ep71078840948%7E&ifkv=Af_xneHYH_D8Mr7v4l5-kJXc3MniY858IF1UmsEa-pRK1soNBV23tHGAuvBO27TBw19t7sJso4kdRQ&osid=1&passive=1209600&service=adwords&flowName=GlifWebSignIn&flowEntry=ServiceLogin" target="_blank" rel="noopener noreferrer">
            
            <div class="social-tab"  style="border: 2px rgba(0, 0, 0, 0.500)solid">
              
              <img class="ss" id="logo"  src="Logo/google.png" alt="">
              Connect with Google
            </div>

          </a>



          <a style="text-decoration: none;" href="https://twitter.com/i/flow/login" target="_blank" rel="noopener noreferrer">
            
            <div class="social-tab"  style="border: 2px rgba(0, 0, 0, 0.500)solid">
              
              <img class="ss" id="logo" src="Logo/twitter.png" alt="">
              Connect with Twitter
            </div>

          </a>

     
                        


        <div class="form-group" style="margin-bottom: 20px;">
          <div class="col-md-8 offset-md-0">
            <button type="submit" class="btn btn-warning">
               Login
            </button>

            <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('Forgot Your Password?')); ?>

                </a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
    
    



<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire\resources\views/auth/login.blade.php ENDPATH**/ ?>