

<?php $__env->startSection('content'); ?>

<!--background image-->
<div class="container">
  <div class="part1">
      <div class="background-image">
          <img class="slide" src="" style="background-image: url(images/service.jpg) ; margin-top: -50px;"alt="">
       <div class="carousel-caption d-none d-md-block">
          <h2 class="nav-heading"> Services</h2>
      </div>    
      </div>
  </div>
</div>
   
<!-- <div class="container">
    <div class="part1">
        <div class="background-image">
            <img class="slide" src="" style="background-image: url(images/pxfuel.jpg);"alt="">
        <div class="carousel-caption d-none d-md-block">
            <h2 style="font: size 50px;">Service</h2>
        </div>    
        </div>
    </div> -->

<!--background image-->



   

    <!-- ========== Start Services ========== -->

    <div class="container-fluid row flex-wrap bg-none"style="margin-top: 200px">
        <div class="col-md-3 text-center p-5">

          <img class="service-img m-3 service-img-flight" src="Logo/flight1.png" alt="" srcset="">

          <p style="font-size: x-large;">Amazing Travel</p>
          <p style="text-align: justify;">Separated they live in Bookmarksgrove right at the coast of the Semantics, a
            large language ocean. A small river named Duden flows by their place and supplies</p>
        </div>

        <div class="col-md-3 text-center  p-5     ">
          <div class="col">
            <img class="service-img m-3" src="Logo/ship (1).png" alt="" srcset="">
          </div>
          <p style="font-size: x-large;">Our Cruises</p>
          <p style="text-align: justify;">Separated they live in Bookmarksgrove right at the coast of the Semantics, a
            large language ocean. A small river named Duden flows by their place and supplies</p>
        </div>

        <div class="col-md-3 text-center  p-5     ">
          <div class="col">
            <img class="service-img m-3" src="Logo/business-trip.png" alt="" srcset="">
          </div>
          <p style="font-size: x-large;">Book Your Trip</p>
          <p style="text-align: justify;">Separated they live in Bookmarksgrove right at the coast of the Semantics, a
            large language ocean. A small river named Duden flows by their place and supplies</p>
        </div>

        <div class="col-md-3 text-center   p-5    ">
          <div class="col">
            <img class="service-img m-3" src="Logo/technical-support.png" alt="" srcset="">
          </div>
          <p style="font-size: x-large;">Nice Support</p>
          <p style="text-align: justify;">Separated they live in Bookmarksgrove right at the coast of the Semantics, a
            large language ocean. A small river named Duden flows by their place and supplies</p>
        </div>
      </div>


      <!-- ========== End Services ========== -->



    
<!-- ========== Start Sign Up for a Newsletter ========== -->
<div class="container">
<div class=" signup-newsletter flex-nowrap my-5" id="signup-newsletter-service" style="margin-left: -120px;">
 
    <h1 class="h1-h4">Sign Up for a Newsletter</h1>
    <h4 class="h1-h4">Sign up for our mailing list to get latest updates and offers.</h4>
    <div id="news-div" class="col-md-4">
      
      <form action="" method="get">
        <input id="news-div-email" type="email" placeholder="Enter Your Email" required="">
        <input id="news-div-submit" type="submit">
      </form>
    </div>
  
      
  </div>
  




      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire\resources\views/services/service.blade.php ENDPATH**/ ?>