<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>mrs culture</title>
  <link rel="stylesheet" href="<?php echo e(asset('cssfile/style.css')); ?>">
  <!-- Bootstrap Link -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- Bootstrap Link -->

  <!-- Font Awesome cdn -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Font Awesome cdn -->

  <!-- jQuery Link -->

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="<?php echo e(asset('java/jquery.js')); ?>"></script>
  <!-- javascript Link -->
  <script src="<?php echo e(asset('java/javaScript.js')); ?>"></script>
  <style>
    body{
        background-image: url(images/registration-bg.jpg);
        background-size: cover;
        overflow-x: hidden;
    }
  </style>
</head>

<body>

    <div class="container-sm" style="margin-left: 13%; margin-top: 20%;color: white; font-size: x-large;">
    <div>
        <img src="Logo/Mrs web icon png.png" style="width: 60px;" alt="">
        Mrs Culture
        </div>
        <div>
            Sign in or create an account
        </div>
    </div>
    
    <div class="container-sm" style="margin-left: 90%; margin-top: 15%;">
        <div class="bg-light" style=" width: 50px; border-radius: 50px;">
           <a href=""><img src="Logo/technical-support.png" style="width: 50px;  border-radius: 50px;" alt=""></a>
            
        </div>
        <div class="modal-content" style="width: 500px; margin-top: -45%; margin-left: -50%;">
        </div>


</body>

</html>

   <?php /**PATH C:\xampp\htdocs\livewire\resources\views/log.blade.php ENDPATH**/ ?>