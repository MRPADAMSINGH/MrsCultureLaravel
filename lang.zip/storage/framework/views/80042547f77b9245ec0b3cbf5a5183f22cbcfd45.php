<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Image Gallery - Bootstrap 5</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/gallery.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="heading">
                <h3>Dress <span>Gallery</span></h3>
            </div>

            <section class="gallery min-vh-100">
                <div class="container-lg">
                    <div class="row gy-4 row-cols-1 row-cols-sm-2
                        row-cols-md-3">
                        <!-- <div class="col">
                            <img src="dress image/1.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/2.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/3.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/4.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/5.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/6.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/7.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/8.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/9.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/10.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/11.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/12.png" class="gallery-item"
                                alt="gallery">
                        </div> -->
                        <div class="col">
                            <img src="dress image/13.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/14.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/15.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/16.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/17.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/18.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/19.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/20.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/21.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/22.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/23.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/24.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <!-- <div class="col">
                            <img src="dress image/25.png" class="gallery-item"
                                alt="gallery">
                        </div> -->
                        <div class="col">
                            <img src="dress image/26.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/27.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/28.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/29.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/30.png" class="gallery-item"
                                alt="gallery">
                        </div>
                    </div>
                </div>
            </section>


            <section class="gallery min-vh-100">
                <div class="container-lg">
                    <div class="row gy-4 row-cols-1 row-cols-sm-2
                        row-cols-md-3">
                        <div class="col">
                            <img src="dress image/31.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/32.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/33.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/34.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/35.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/36.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/37.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/38.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/39.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/40.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/41.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/42.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/43.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/44.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/45.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/46.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/47.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/48.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/49.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/50.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dress image/32.png" class="gallery-item"
                                alt="gallery">
                        </div>
                    </div>
                </section>


                <footer>

                    <div id="footer" class="container-fluid " style="margin-top: -150px; padding: 100px; color: white;">
                      <div class="row m-5"  style="padding-top: 100px;">
                        <div class="col-md-3">
                          <h6>Mrs Culture Agency</h6>
                          <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
                          <a href=""><img class="news-logo" src="Logo/facebook (1).png" alt=""></a>
                          <a href=""><img class="news-logo" src="Logo/twitter.png" alt=""></a>
                          <a href=""><img class="news-logo" src="Logo/instagram (1).png" alt=""></a>
                          <a href=""><img class="news-logo" src="Logo/youtube (1).png" alt=""></a>
                        </div>
                      
                        <div class="col-md-1" style="font-size: smaller;">
                          <h6>Book Now</h6>
                          <div>Flight</div>
                          <div>Hotels</div>
                          <div>Tour</div>
                          <div>Car Rent</div>
                          <div>Beach & Resorts</div>
                          <div>Cruises</div>
                        </div>
                      
                        <div class="col-md-1" style="font-size: smaller;">
                          <h6>Top Deals</h6>
                          <div>Edina Hotel</div>
                          <div>Quality Suites</div>
                          <div>The Hotel Zephyr</div>
                          <div>Da Vinci Villa</div>
                          <div>Hotel Epikk</div>
                        </div> 
                      
                        <div class="col-md-4" style="font-size: smaller;">
                          <h6>Blog Post</h6>
                          <div>The Ultimate Packing List For Female Travelers</div>
                          <div>How These 5 People Found The Path to Their Dream Trip</div>
                          <div>A Definitive Guide to the Best Dining and Drinking Venues in the City</div>
                        </div>
                      
                        <div class="col-md-3" style="font-size: smaller;">
                          <h6>Contact Information</h6>
                          <div>Address: Mumbai</div>
                          <div><a href="mailto:mrsculture.offical@gmail.com" style="text-decoration: none; color: white;">mrsculture.offical@gmail.com</a></div>
                          <div><a href="tel:+919310521020"></a>+919310521020</div>
                        
                        </div>
                      </div>
                    </div>
                    
                    
                  
                  </footer>
                  






                <script src="js/bootstrap.bundle.min.js"></script>
                <script src="js/main.js"></script>
            </body>
        </html><?php /**PATH C:\xampp\htdocs\livewire\resources\views/dress.blade.php ENDPATH**/ ?>