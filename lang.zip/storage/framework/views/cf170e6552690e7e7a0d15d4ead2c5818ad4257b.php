

<?php $__env->startSection('content'); ?>
<style>
  body{
    background-image: url('images/flight-bg.jpg');
    background-position: center;
    background-size: cover
  }
  table{
    margin: 5%
  }
  .flight-hover:hover{
    background: white;
    
  }
</style>

<div class="container-fluid" style="">
  
  
  <div class="container-fluid" style="margin-top: 10%; width:1400px">
    
    <h3>Flghts</h3>
    <hr style="color: orange; height:10px">
    

    <div class="col-md-12">
        <?php $__currentLoopData = $flight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <div class="p-2 col-sm-11 hotel-card flight-hover">
          
          <div style="display: flex">
            
            <div class="col-sm-3">
              <h5> <span style="font-size: small">From</span> <strong><?php echo e($flight->from); ?></strong> </h5>
              <h5> <span style="font-size: small">To</span> <strong><?php echo e($flight->to); ?></strong> </h5>
           
            </div>

            <div class="col-sm-3">
              <h5 > <span style="font-size: small">Departuredate </span><?php echo e($flight->departuredate); ?></h5>
             

            </div>

            <div class="col-sm-3">
              <h5 > <span style="font-size: small">Time </span><?php echo e($flight->time); ?></h5>
             
              
            </div>
            <div class="col-sm-2">
              
              <h5 > <span style="font-size: small">Amount ₹ </span><?php echo e($flight->amount); ?></h5>
            
              
            </div>


            <div class="col-sm-1">

              <a href="flight-booking" class="btn btn-primary">Book Now</a>
            </div>

           
          
            
          </div>
          </div>
        
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    

  </div>                 
   
</div>
 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\livewire\resources\views/flight/index.blade.php ENDPATH**/ ?>