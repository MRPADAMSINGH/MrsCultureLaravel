<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form by livewire</title>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form')->html();
} elseif ($_instance->childHasBeenRendered('In8Xl4y')) {
    $componentId = $_instance->getRenderedChildComponentId('In8Xl4y');
    $componentTag = $_instance->getRenderedChildComponentTagName('In8Xl4y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('In8Xl4y');
} else {
    $response = \Livewire\Livewire::mount('form');
    $html = $response->html();
    $_instance->logRenderedChild('In8Xl4y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <?php echo \Livewire\Livewire::scripts(); ?>


</body>
</html><?php /**PATH C:\xampp\htdocs\livewire\resources\views/formwire.blade.php ENDPATH**/ ?>