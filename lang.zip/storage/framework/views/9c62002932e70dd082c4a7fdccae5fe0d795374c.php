<div>
    Hello Dear!
</div>
<?php /**PATH C:\xampp\htdocs\livewire\resources\views/livewire/hello.blade.php ENDPATH**/ ?>