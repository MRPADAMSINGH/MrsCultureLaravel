
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Image Gallery - Bootstrap 5</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="dresscss/gallery.css">
        <link rel="stylesheet" type="text/css" href="dresscss/style.css">

    </head>
    <body>
        <div class="container">
            <div class="heading">
                <h3>Dress <span>Gallery</span></h3>
            </div>

            <section class="gallery min-vh-100">
                <div class="container-lg">
                    <div class="row gy-4 row-cols-1 row-cols-sm-2
                        row-cols-md-3">
                        <!-- <div class="col">
                            <img src="dressimage/1.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/2.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/3.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/4.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/5.png" class="gallery-item" alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/6.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/7.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/8.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/9.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/10.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/11.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/12.png" class="gallery-item"
                                alt="gallery">
                        </div> -->
                        <div class="col">
                            <img src="dressimage/13.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/14.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/15.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/16.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/17.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/18.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/19.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/20.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/21.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/22.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/23.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/24.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <!-- <div class="col">
                            <img src="dressimage/25.png" class="gallery-item"
                                alt="gallery">
                        </div> -->
                        <div class="col">
                            <img src="dressimage/26.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/27.jpg" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/28.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/29.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/30.png" class="gallery-item"
                                alt="gallery">
                        </div>
                    </div>
                </div>
            </section>


            <section class="gallery min-vh-100">
                <div class="container-lg">
                    <div class="row gy-4 row-cols-1 row-cols-sm-2
                        row-cols-md-3">
                        <div class="col">
                            <img src="dressimage/31.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/32.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/33.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/34.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/35.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/36.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/37.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/38.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/39.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/40.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/41.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/42.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/43.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/44.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/45.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/46.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/47.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/48.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/49.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/50.png" class="gallery-item"
                                alt="gallery">
                        </div>
                        <div class="col">
                            <img src="dressimage/32.png" class="gallery-item"
                                alt="gallery">
                        </div>
                    </div>
                </section>


            </body>
        </html>
<?php /**PATH C:\xampp\htdocs\livewire\resources\views/dress/dress.blade.php ENDPATH**/ ?>