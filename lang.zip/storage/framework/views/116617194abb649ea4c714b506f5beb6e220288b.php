<!DOCTYPE html>
<html lang="en">
<head>
    <title>livewire first program</title>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello')->html();
} elseif ($_instance->childHasBeenRendered('vZ6at0B')) {
    $componentId = $_instance->getRenderedChildComponentId('vZ6at0B');
    $componentTag = $_instance->getRenderedChildComponentTagName('vZ6at0B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vZ6at0B');
} else {
    $response = \Livewire\Livewire::mount('hello');
    $html = $response->html();
    $_instance->logRenderedChild('vZ6at0B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <?php echo \Livewire\Livewire::scripts(); ?>


</body>
</html><?php /**PATH C:\xampp\htdocs\livewire\resources\views/hellowire.blade.php ENDPATH**/ ?>