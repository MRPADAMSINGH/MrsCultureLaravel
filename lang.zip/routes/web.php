<?php

use Illuminate\Support\Facades\Route;
use Livewire\LivewireComponentsFinder;
use App\Http\Controllers\loginform;
use App\Http\Controllers\webtest;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();
//home page
Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
//Destination
Route::get('/destination', [App\Http\Controllers\HomeController::class, 'destination'])->name('destination');


//Cruises
Route::get('/cruises', [App\Http\Controllers\HomeController::class, 'cruises'])->name('cruises');

//Hotel
Route::get('/hotel', [App\Http\Controllers\HomeController::class, 'hotel'])->name('hotel');

//Flight below routh
Route::get('/flight', [App\Http\Controllers\HomeController::class, 'flight'])->name('flight');
//view flight route to flight form
Route::get('/flightbooking', [App\Http\Controllers\HomeController::class, 'fview']);

//booking form for flight
Route::get('flight-booking', [App\Http\Controllers\HomeController::class, 'book'])->name('book');
//fetch data

Route::post('fetch', [App\Http\Controllers\BookController::class, 'dataget'])->name('dataget');

//view flight all booking details
Route::get('/flightbooking', [App\Http\Controllers\BookController::class, 'index']);


//Edit Flight this route for open a normal form, Below both line for edit and update
// Route::get('/book-flight/{id}', [App\Http\Controllers\HomeController::class, 'book'])->name('book');

//booking form for flight
// Route::get('flight-booking', [App\Http\Controllers\BookController::class, 'book'])->name('book');

//Update Flight dont comment out below line.

// Route::put('/bookflight', [App\Http\Controllers\HomeController::class, 'bookingflight'])->name('bookingflight');

//Update Flight.

// Route::put('/bookflight', [App\Http\Controllers\HomeController::class, 'bookingflight'])->name('bookingflight');


//Blog
Route::get('/blog', [App\Http\Controllers\HomeController::class, 'blog'])->name('blog');

//dress
Route::get('/dress', [App\Http\Controllers\HomeController::class, 'dress'])->name('dress');

//dress
Route::get('/photo', [App\Http\Controllers\HomeController::class, 'photo'])->name('photo');


// Route::get('add-flight', [App\Http\Controllers\FlightController::class, 'add'])->name('add');
// Route::post('flightdata', [App\Http\Controllers\FlightController::class, 'flightdata']);

//contact
Route::get('/contact', [App\Http\Controllers\HomeController::class, 'contact'])->name('contact');


//services
Route::get('/services', [App\Http\Controllers\HomeController::class, 'services'])->name('services');







