<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Livewire\Livewire;

class webtest extends Controller
{
    public function index(){
        return view('webpage');
    }



}
