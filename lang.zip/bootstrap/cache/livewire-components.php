<?php return array (
  'fo45' => 'App\\Http\\Livewire\\Fo45',
  'form' => 'App\\Http\\Livewire\\Form',
  'hello' => 'App\\Http\\Livewire\\Hello',
);