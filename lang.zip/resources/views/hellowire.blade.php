<!DOCTYPE html>
<html lang="en">
<head>
    <title>livewire first program</title>

    @livewireStyles
</head>

<body>
@livewire('hello')


    @livewireScripts

</body>
</html>