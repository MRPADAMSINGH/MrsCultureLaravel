<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form by livewire</title>

    @livewireStyles
</head>

<body>
@livewire('form')


    @livewireScripts

</body>
</html>