<!doctype html>
<html lang="en">

<head>
  <title>Title</title>

<style>
</style>
</head>

<body>
  <h2>Create a web Application which demonstrate routing through controller</h2>


</body>

</html>