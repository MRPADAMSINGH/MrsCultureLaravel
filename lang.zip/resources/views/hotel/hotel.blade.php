@extends('layouts.app')

@section('content')

 <link rel="stylesheet" href="cssfile/hotel.css">
</head>

<body>


  <div class="container-fluid" id="main-top">


        <!-- here we are insert images -->
        <div class="part1 ">
          <div class="banner1">
            <img class="slide" src="" style="background-image: url(images/h-banner1.jpg);">
            <div class="carousel-caption d-none d-md-block">
              <p class="img-text">Make yourself at home</p>
              <h6 class="img-text-h">Comfort is our business</h6>
    
            </div>
    
          </div>
    
          <div class="banner2">
            <img class="slide" src="" style="background-image: url(images/h-banner2.jpg);">
            <div class="carousel-caption d-none d-md-block">
              <p class="img-text">Excellent hotel located</p>
              <h6 class="img-text-h">at an excellent location</h6>
    
            </div>
          </div>
    
          <div class="banner3">
            <img class="slide" src="" style="background-image: url(images/h-banner3.jpg);">
            <div class="carousel-caption d-none d-md-block">
              <p class="img-text">Is one of the best destination</p>
              <h6 class="img-text-h">to stay with family</h6>
    
            </div>
          </div>
    
          <div class="banner4">
            <img class="slide" src="" style="background-image: url(images/h-banner4.jpg);">
            <div class="carousel-caption d-none d-md-block">
              <p class="img-text">Well-appointed rooms</p>
              <h6 class="img-text-h">at great place</h6>
    
            </div>
          </div>
    
        </div>
        
    <!-- Start Hotel -->
    
          <div class="container-fluid" style="display: flex;">
            
            <div class="f-hotel col-9">

                <div class="container-fluid row " style="margin-top: 150px;">
                  
                    <div class="card col-md-3 p-2 hotel-card card-div" style="width: 18rem;">
                      <img src="images/hotel10.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Hotel Vintage Manali</h5>
                      <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-full.png"><img class="star" src="Logo/star-half.png"><span> 435 Reviews</span></p>
                        3 star Hotel in Manali<br>
                        Balcony's rooms are good view wise one of the best.</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel11.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">The Anantmaya Resort</h5>
                      <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-half.png"><span> 355 Reviews</span></p>
                        2 star Hotel in Pune<br>
                        Excellent hotel located at an excellent location</p>
                      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
            
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel3.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Treebo Trend Hotel</h5>
                      <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                        src="Logo/star-full.png"><span> 185 Reviews</span></p>
                        3 star Hotel in Banglore<br>
                        Is one of the best destination to stay with family</p>
                      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel12.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Hill County Resort</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><span> 605 Reviews</span></p>
                          5 star Hotel in Mumbai<br>
                          Sea view is a very good for peaceful location</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
            
                    <div class="card col-md-5 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel5.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Highland Park Resort</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 311 Reviews</span></p>
                          4 star Hotel in Noida<br>
                          Explore top attractions & restaurants in and around area</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel6.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Hotel Royal</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-half.png"><span> 96 Reviews</span></p>
                          3 star Hotel in Lucknow<br>
                          Great place close to the airport, super friendly staff.</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel7.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Hotel Kemps Corner</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 123 Reviews</span></p>
                          4 star Hotel in Nagpur<br>
                          The Hotel provides Car rental service facilitate</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
            
                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel8.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Shine Blue Resort</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 399 Reviews</span></p>
                          5 star Hotel in Goa<br>
                          A 5-star deluxe hotel issued by the Ministry of Tourism</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>
 

                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel9.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Everest Hotel</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 247 Reviews</span></p>
                          5 star Hotel in Jodhpur<br>
                          Comfortable and well done rooms, great buffet breakfast</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>

                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel14.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Orchards Hotel</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 149 Reviews</span></p>
                          5 star Hotel in Ranchi<br>
                          Well-appointed rooms, a great outdoor dining spot.</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>

                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel8.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">The Meadows Hotel</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 98 Reviews</span></p>
                          4 star Hotel in Nashik<br>
                          Featuring a restaurant room service and free WiFi.</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>

                    <div class="card col-md-3 p-2 hotel-card" style="width: 18rem;">
                      <img src="images/hotel-9.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Galaxy Hotel Inn</h5>
                        <p class="card-text"><p style="color: black;"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><img class="star" src="Logo/star-full.png"><img class="star"
                          src="Logo/star-full.png"><span> 98 Reviews</span></p>
                          3 star Hotel in Bhopal<br>
                          All rooms are fitted with a wardrobe with a flat-screen TV</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Book Now</button>
                     
                      </div>
                    </div>


                  </div>

            </div>

            <div class="s-hotel col-3" style="color: black; margin-top: 150px;">
                <!--form start -->
    <form>
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Hotel Booking</h5>
            
          </div>
        <div class="mb-3"style="">
          
          <label for="inputName" class=" col-form-label ps-1">Name:</label>
  
          <input type="text" class="form-control  border-3" name="inputName" id="inputName" placeholder="Enter Your Full Name"required>
        </div>
        <div class="mb-3"style="">
          
          <label for="email" class=" col-form-label ps-1">Email:</label>
  
          <input type="email" class="form-control  border-3" name="email" id="email" placeholder="Enter Your  Email"required>
        </div>
        <div class="mb-3">
          <label for="From" class=" col-form-label ps-1">Hotels:</label>

          <select name="hotels"class="form-control  border-3"name="hotels" id="hotels">
            <option value="">Select a hotel</option>
            <option value="hotels">Shine Blue Resort</option>
            <option value="hotels">The Anantmaya Resort</option>
            <option value="hotels">Treebo Trend Hotel</option>
            <option value="hotels">Hill County Resort</option>
            <option value="hotels">Highland Park Resort</option>
            <option value="hotels">Hotel Royal</option>
            <option value="hotels">Hotel Kemps Corner</option>
            <option value="hotels">Shine Blue Resort</option>
            <option value="hotels">Everest Hotel</option>
            <option value="hotels">Orchards Hotel</option>
            <option value="hotels">The Meadows Hotel</option>
            <option value="hotels">Galaxy Hotel Inn</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="Adults" class=" col-form-label ps-1">Adults</label>

          <select name="Adults"class="form-control  border-3"name="Adults" id="Adults">
            <option value="Adults">0</option>
            <option value="Adults">1</option>
            <option value="Adults">2</option>
            <option value="Adults">3</option>
            <option value="Adults">4</option>
          </select>
        </div>

        
        <div class="mb-3">
          <label for="children" class=" col-form-label ps-1">children</label>

          <select name="children"class="form-control  border-3"name="children" id="children">
            <option value="children">0</option>
            <option value="children">1</option>
            <option value="children">2</option>
            <option value="children">3</option>
            <option value="children">4</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="inputName" class=" col-form-label ps-1">Check-in:</label>
  
          <input type="date" class="form-control  border-3" name="inputdate" id="inputdate" placeholder="Name">
        </div>

        <div class="mb-3">
          <label for="inputName" class=" col-form-label ps-1">Check-out:</label>
  
          <input type="date" class="form-control  border-3" name="inputdate" id="inputdate" placeholder="Name">
        </div>

  
        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
      </form>
      <!--form end-->
            </div>

  </div>
         

  <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false"
  aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header ">
        <h5 class="modal-title" id="exampleModalLabel"><strong>Hotel Booking</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
            
            <div class="col-md-12" style="display: flex;">
                <div class="col-6"style="">
              
                    <label for="inputName" class=" col-form-label ps-1">Name:</label>
            
                    <input type="text" class="form-control  border-3" name="inputName" id="inputName" placeholder="Enter Your Full Name"required>
                  </div>
                  <div class="col-6"style="">
                    
                    <label for="email" class=" col-form-label ps-1">Email:</label>
            
                    <input type="email" class="form-control  border-3" name="email" id="email" placeholder="Enter Your  Email"required>
                  </div>
            </div>
            <div class="mb-3">
              <label for="From" class=" col-form-label ps-1">Hotels:</label>
    
              <select name="hotels"class="form-control  border-3"name="hotels" id="hotels">
                <option value="">Select a hotel</option>
                <option value="hotels">Shine Blue Resort</option>
                <option value="hotels">The Anantmaya Resort</option>
                <option value="hotels">Treebo Trend Hotel</option>
                <option value="hotels">Hill County Resort</option>
                <option value="hotels">Highland Park Resort</option>
                <option value="hotels">Hotel Royal</option>
                <option value="hotels">Hotel Kemps Corner</option>
                <option value="hotels">Shine Blue Resort</option>
                <option value="hotels">Everest Hotel</option>
                <option value="hotels">Orchards Hotel</option>
                <option value="hotels">The Meadows Hotel</option>
                <option value="hotels">Galaxy Hotel Inn</option>
              </select>
            </div>
            <div class="col-md-12" style="display: flex;">
            <div class="col-6">
              <label for="Adults" class=" col-form-label ps-1">Adults</label>
    
              <select name="Adults"class="form-control  border-3"name="Adults" id="Adults">
                <option value="Adults">0</option>
                <option value="Adults">1</option>
                <option value="Adults">2</option>
                <option value="Adults">3</option>
                <option value="Adults">4</option>
              </select>
            </div>
    
            
            <div class="col-6">
              <label for="children" class=" col-form-label ps-1">children</label>
    
              <select name="children"class="form-control  border-3"name="children" id="children">
                <option value="children">0</option>
                <option value="children">1</option>
                <option value="children">2</option>
                <option value="children">3</option>
                <option value="children">4</option>
              </select>
            </div>

            </div>
    
            <div class="mb-3">
              <label for="inputName" class=" col-form-label ps-1">Check-in:</label>
      
              <input type="date" class="form-control  border-3" name="inputdate" id="inputdate" placeholder="Name">
            </div>
    
            <div class="mb-3">
              <label for="inputName" class=" col-form-label ps-1">Check-out:</label>
      
              <input type="date" class="form-control  border-3" name="inputdate" id="inputdate" placeholder="Name">
            </div>
    
            <button type="submit" class="btn btn-primary" id="submit">Login</button>
        </form>
            

        </div>

      </div>
      <div class="modal-footer">
        


    </div>
  </div>
</div>



  
      <script> 
          const submitButton = document.getElementById('submit'); 
                 submitButton.addEventListener('click', function() { 
           alert('your request is in process!'); 
          });
       </script>


</body>
</html>
@endsection